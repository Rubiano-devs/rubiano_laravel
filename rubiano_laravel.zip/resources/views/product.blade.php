@extends('layouts.app')

@section('content')
<div class="container">
<div class="mb-2 d-flex align-items-center justify-content-between">
<h3>Products</h3>
<a class="btn btn-success" href="{{ route('new-product') }}">Add New</a>
</div>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Product Name</th>
      <th scope="col">Price</th>
      <th scope="col">Quantity</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  @foreach ($products as $product)
    <tr>
      <th scope="row">{{ $product -> id }}</th>
      <td>{{ $product -> name }}</td>
      <td>{{ $product -> price }}</td>
      <td>{{ $product -> quantity }}</td>
      <td>
        <a href="/product/{{ $product-> id }}/edit" class="btn btn-primary btn-sm">Edit</a>
        <a href="#" class="btn btn-danger btn-sm" onclick="deleteProduct({{$product-> id}})" data-toggle="modal" data-target="#exampleModal">Delete</a>
      </td>
    </tr>
@endforeach
  </tbody>
</table>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Confirmation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Are you sure you want to delete this product??
      </div>
      <div class="modal-footer">
      <input type="hidden" id="delete_product">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" onclick="confirmDelete()" class="btn btn-danger">Delete</button>
      </div>
    </div>
  </div>
</div>
@endsection

@section('scripts')
<script>
function deleteProduct(product){
  document.getElementById("delete_product").value = product;
}
function confirmDelete(){
  var prod = document.getElementById("delete_product").value;
  window.location.href = '/product/'+prod+'/delete';
}
</script>
@endsection
